
/* Your Code Below! Enable the following define's 
 * and replace ??? with actual wires */
// ----- signals -----


// ----- signals -----
`define PROBE_DATA_OUT   data_out
 `define PROBE_ADDR       addr
`define PROBE_DATA_IN    data_in
`define PROBE_DATA_OUT   data_out

// ----- design -----
`define TOP_MODULE               pd
// ----- design -----
