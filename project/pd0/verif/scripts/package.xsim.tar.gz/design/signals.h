
`define ASSIGN_AND_X  assign_and_x
`define ASSIGN_AND_Y  assign_and_y
`define ASSIGN_AND_Z  assign_and_z


/* Your Code Below! Enable the following define's 
 * and replace ??? with actual wires */
// ----- signals -----
 `define PROBE_EX33_ARESET  reg_reset
 `define PROBE_EX33_X       reg_and_arst_x
 `define PROBE_EX33_Y       reg_and_arst_y
 `define PROBE_EX33_Z       reg_and_arst_z
// 
 `define PROBE_EX34_X       reg_and_reg_x
 `define PROBE_EX34_Y       reg_and_reg_y
 `define PROBE_EX34_Z       reg_and_reg_z
// ----- signals -----

// ----- design -----
`define TOP_MODULE               pd0
// ----- design -----
